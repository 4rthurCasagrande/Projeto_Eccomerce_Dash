import pandas as pd
from dash import Dash, html, dcc, Input, Output, callback
import plotly.express as px
import statsmodels as sm

def cria_graficos(df):

    # Histograma
    fig1 = px.histogram(df, x='Preço', nbins=30, title='Histograma de Preço')

    # Dispersão
    fig2 = px.scatter(df, x='N_Avaliações', y='Preço')
    fig2.update_layout(
        title='Dispersão: Preço X Número de Avaliações',
        xaxis_title='Número de Avaliações',
        yaxis_title='Preço'
    )

    # Mapa de Calor
    fig3 = px.density_heatmap(df, x='Preço', y='N_Avaliações', color_continuous_scale='icefire')
    fig3.update_layout(
        title='Correlação entre Preço e Número de Avaliações'
    )

    # Barras
    fig4 = px.bar(df, x='Marca', y='Qtd_Vendidos')
    fig4.update_layout(
        title='Marca x Qtd_Vendidos',
        xaxis_title='Marca',
        yaxis_title='Quantidade de Vendidos'
    )

    # Pizza
    fig5 = px.pie(df, names='Gênero', color='Gênero', title='Distribuição por Gênero')

    # Densidade
    fig6 = px.density_contour(df, x='Preço', y='Nota', title='Contorno')

    # Regressão
    fig7 = px.scatter(df, x='N_Avaliações', y='Preço', trendline='ols', title='Regressão Linear - Preço x Número de Avaliações')

    return fig1, fig2, fig3, fig4, fig5, fig6, fig7

def cria_app(df):
    app = Dash(__name__)

    fig1, fig2, fig3, fig4, fig5, fig6, fig7 = cria_graficos(df)

    app.layout = html.Div([
        dcc.Graph(figure=fig1),
        dcc.Graph(figure=fig2),
        dcc.Graph(figure=fig3),
        dcc.Graph(figure=fig4),
        dcc.Graph(figure=fig5),
        dcc.Graph(figure=fig6),
        dcc.Graph(figure=fig7)
    ])
    return app

df = pd.read_csv('ecommerce_estatistica.csv')

if __name__ == '__main__':
    app = cria_app(df)
    app.run(debug=True, port=8060)